#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * @author codewindy
 * @date ${YEAR}-${MONTH}-${DAY} ${TIME}
 * @since 1.0.0
 */
public class ${NAME} {
}